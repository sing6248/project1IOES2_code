
//Written by William Luk
// posts data to an Adafuit.io feed
let url='https://io.adafruit.com/api/v2/daniesingh/feeds/testdata/data';

var data = 0;

function setup() {
//  createCanvas(400,400);
  myButton1 = createButton('LOVE ME');
  myButton2 = createButton('FEED ME');
  myButton1.mousePressed(press);
  myButton1.mouseReleased(off);
  myButton2.mousePressed(feedme);
  myButton2.mouseReleased(off);
}

function draw() {
//  background(120);
    myButton1.style('background-color','FF0F00');
    myButton2.style('background-color','00C5FF');
    myButton1.position(600, 400);
    myButton2.position(850, 400);
    myButton1.size(200,100);
    myButton2.size(200,100);
}

function press(){
  data = 1;
  console.log(data);
  sendData(data);
}

function feedme(){
    data = 2; 
    console.log(data); 
    sendData(data);
}

function off() {
  data = 0;
  console.log(data);
  sendData(data);
}

function sendData(turnOn){
  let postData ={
    "value": turnOn,
    "X-AIO-Key": "aio_ezpZ885iwerc7Pdt2JmmFtrsXaRM"
  };
  httpPost(url, 'json', postData, function(result){
    console.log(result);
  });
}